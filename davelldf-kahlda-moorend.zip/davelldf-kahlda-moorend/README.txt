Folders:
	-->filtered_imgs:       location to store images with overlaid tracks
	-->hough_example_pics:  Pictures used in demonstrating Hough Transform
	-->QF2-1_5160-5240:     Sample extracted frames from sample clip
	-->testSegmented:       Training and test data sets for the SVM


For Hough Transforms:
	Run "hough_stough.m"
	-->Uses the following functions:
		-clean_mask_hough.m
		-drawParallelLines.m
	-->Uses images from the directory:
		-"/hough_example_pics"

	-->Input: Change the image name at the beginning of the file to change input
	-->Output: Uses imshow to show masks and results

	
For FRC SVM:
	Run "imageReader.m"
	Run "frcSVM.m":  creates and trains the svm

	-->Output:
		- "features.mat": represents each testing and training image split into seven-by-seven grids for the SVM
		- "frcSVMNetwork.mat":  resultant SVM network

	Files:
	frcSVM.m: Uses output of imageReader.m to create an train an SVM. Outputs said SVM to "frcSVMNetwork.mat".
	imageReader.m: Loads images in "segmented" and "testSegmented" directories for usage by "frcSVM.m".
	extractFeatureVector.m: Used by "imageReader.m" to extract a 294-dimension feature vector (from a 7x7 grid) from each provided testing or training image.
	normalizeFeatures01.m: Used by "imageReader.m" to normalize all extracted features so they can safely be compared to one another. Provided by Dr. Boutell.

	The following SVM engine files are provided by Anton Schwaighofer.
	svmtrain.m: Used by "frcSVM.m" to perform SVM training.
	svmfwd.m: Used to classify an image using an SVM.
	svm.m: Used by "frcSVM.m" to create an SVM network.
	svmkernel.m: Includes several SVM kernels.
	svmcv.m: Performs Cross-Validation of an SVM.
	svmstat.m: Provides statistics about an SVM.
	consist.m: Performs parameter checking used in SVM code.
	
	
For image subtraction:
	Run "imsubtract.m"
	-->Uses the following class:
		-Image.m
	-->Uses the following functions:
		-clean_mask_imsubtract.m
		-bounding_box.m
	-->Uses images from directory:
		-"/QF2-1_5160-5240"
		-Can be changed in the code

	-->Input: Images from specified directory, numbered consecutively
	-->Outputs: 
		-Saves bounding boxed images to directory "/boxed"
		-Saves centroid information to "centroids.mat"
		--> Format for each row:
			<centroid_row> <centroid_col> <frame_number>
			

			
To track the robot and output the tracks:
	Run "tracking.m"
	--> Uses centroids.mat (output of imsubtract.m or svm)
	--> Requires a folder name "filtered_imgs" to be created in the directory
		- Used for saving images with overlaid centroids

	--> Outputs
		- Images into filtered_imgs folder
		- A clip of the robots and their tracks (filtered.avi)